# BFGMiner Setup Guide

## Introduction
BFGMiner is a modular ASIC/FPGA miner written in C, featuring dynamic clocking, monitoring, and remote interface capabilities.

## System Requirements
- Linux, Windows, or macOS
- 4GB RAM minimum
- Stable internet connection
- Supported hardware: ASIC miners (Bitmain Antminer series), FPGA boards

## Installation

### Linux (Ubuntu/Debian)
1. Update system:
   ```
   sudo apt update && sudo apt upgrade -y
   ```

2. Install dependencies:
   ```
   sudo apt install build-essential autoconf automake libtool pkg-config libcurl4-openssl-dev libudev-dev libjansson-dev libncurses5-dev -y
   ```

3. Download and build BFGMiner:
   ```
   git clone https://github.com/luke-jr/bfgminer.git
   cd bfgminer
   ./autogen.sh
   ./configure --enable-scrypt
   make -j$(nproc)
   sudo make install
   ```

### Windows
1. Download pre-compiled binaries from official releases.
2. Extract to a folder (e.g., C:\BFGMiner).
3. Add to PATH or run from folder.

## Configuration

1. Create config file `bfgminer.conf`:
   ```
   {
       "pools" : [
           {
               "url" : "stratum+tcp://pool.example.com:3333",
               "user" : "your_worker",
               "pass" : "password"
           }
       ],
       "api-listen" : true,
       "api-port" : "4028",
       "api-allow" : "W:127.0.0.1"
   }
   ```

2. Run BFGMiner:
   ```
   bfgminer --config bfgminer.conf
   ```

## Pool Setup
- Sign up at a mining pool (e.g., Slush Pool, F2Pool).
- Configure worker credentials in config file.

## Monitoring
- Access API at http://localhost:4028
- Use CGMiner API compatible tools for monitoring.

## Troubleshooting
- Check logs for errors.
- Ensure firewall allows API port.
- Verify pool connection with `ping pool.example.com`.

## Security
- Never share your wallet address publicly.
- Use strong passwords for pool accounts.
- Keep software updated.

For support, visit the official BFGMiner GitHub or mining forums.
